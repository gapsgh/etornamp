@extends('admin.layout')

@section('content')
	<h2 class="pull-right">Create Category</h2>
	<form>
		
	</form>
@stop