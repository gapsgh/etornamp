<?php $__env->startSection('title'); ?>
	Promotegh.com - Product Save Successful.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-container">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 page-sidebar">
				<?php echo $__env->make('site.admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
								
				<div class="col-sm-9 page-content">
					<div class="inner-box">
						<h2 class="title-2"><i class="icon-docs"></i> Pending Approval </h2>
						<div class="table-responsive">
							<div class="table-action">
								<div class="table-search pull-right col-xs-7">
									<div class="form-group">

									</div>
								</div>
							</div>
							<table id="addManageTable" class="table table-striped table-bordered add-manage-table table demo" data-filter="#filter" data-filter-text-only="true">
								<thead>
									<tr>
										<th> Photo</th>
										<th data-sort-ignore="true"> Adds Details</th>
										<th data-type="numeric"> Price</th>
										<th> Option</th>
									</tr>
								</thead>
								<tbody>
								<?php $__currentLoopData = $unapproved_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php echo $__env->make('site.admin.products.product_row', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>

				</div>
			</div>

		</div>

	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
		    $('#addManageTable').DataTable();
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>