<?php $__env->startSection('title'); ?>
	Welcome to Promotegh.com
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="main-container">
	<div class="container">
		<div class="col-lg-12 content-box ">
			<div class="row row-featured row-featured-category">
				<div class="col-lg-12  box-title no-border">
					<div class="inner"><h2><span>
					<?php if(isset($category)): ?>
						<?php echo e($category['name']); ?>

					<?php else: ?>
						<?php echo e('All'); ?>

					<?php endif; ?>
					 ></span>
						Sub Categories </h2>
					</div>
				</div>
				<?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 f-category">
						<a href="/category/<?php echo e($category_sub['id']); ?>/<?php echo e(strtolower(str_replace(' ','-',$category_sub['name']) )); ?>"><img src="/uploads/category_images_thumb/<?php echo e($category_sub['image']); ?>" class="img-responsive" alt="img">
							<h6> <?php echo e($category_sub['name']); ?> </h6></a>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div style="clear: both"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>