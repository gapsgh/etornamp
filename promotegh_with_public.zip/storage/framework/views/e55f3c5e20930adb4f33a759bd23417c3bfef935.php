<?php $__env->startSection('title'); ?>
	Welcome to Promotegh.com
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="main-container">
	<div class="container">
	
		<div class="row">
	<div class="col-sm-9 page-content col-thin-right">
	<div class="inner-box category-content">
		<div class="col-lg-12  box-title no-border">
					<div class="inner"><h2><span>
					<?php if(isset($category)): ?>
						<?php echo e($category['name']); ?>

					<?php else: ?>
						<?php echo e('All'); ?>

					<?php endif; ?>
					 ></span>
						Sub Categories </h2>
					</div>
				</div>
				<?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-lg-3 col-md-4 col-sm-4 col-xs-4 f-category">
						<a href="<?php echo e(url(sprintf('category/%d/%s',$category_sub['id'],make_slug($category_sub['name']) ) )); ?>"><img src="<?php echo e(cateory_images_path().$category_sub['image']); ?>" class="img-responsive" alt="img">
							<h6> <?php echo e($category_sub['name']); ?> </h6></a>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<div class="inner-box has-aff relative">
			<a class="dummy-aff-img" href="#"><img src="<?php echo e(url('images/all_products.jpg')); ?>" class="img-responsive" alt=" indomie"> </a>
		</div>
		
	</div>
	<div class="col-sm-3 page-sidebar col-thin-left">
		<aside>
			<div class="inner-box no-padding">
				<img class="img-responsive" src="<?php echo e(url('images/migcloth.png')); ?>" alt="">
			</div>

			<div class="inner-box no-padding">
				<img class="img-responsive" src="<?php echo e(url('images/add2.jpg')); ?>" alt="">
			</div>

		</aside>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>