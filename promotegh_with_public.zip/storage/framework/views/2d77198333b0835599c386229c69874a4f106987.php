<div class="adds-wrapper">

						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<div class="item-list">

								<?php if($product->premiun_status == 1): ?>

									<div class="cornerRibbons urgentAds">
										<a href="<?php echo e(url(sprintf('product/%d/%s',$product->id,make_slug($product->name)))); ?>"> Urgent</a>
									</div>

								<?php elseif($product->premiun_status == 2): ?>

									<div class="cornerRibbons topdAds">
										<a href="<?php echo e(url(sprintf('product/%d/%s',$product->id,make_slug($product->name)))); ?>"> Top Ads</a>
									</div>

								<?php elseif($product->premiun_status == 3): ?>

									<div class="cornerRibbons featuredAds">
										<a href="<?php echo e(url(sprintf('product/%d/%s',$product->id,make_slug($product->name)))); ?>"> Featured Ads</a>
									</div>

								<?php endif; ?>
								<div class="col-sm-2 no-padding photobox">
									<div class="add-image">
										<span class="photo-count"><i class="fa fa-camera"></i> <?php echo e(count($product->image)); ?> </span>
										<a href="<?php echo e(url(sprintf('product/%d/%s',$product->id,make_slug($product->name)))); ?>">
											<img class="thumbnail no-margin" 
												src="<?php if( count($product->image) > 0 ): ?>
													<?php echo e(url(product_images_path().$product->image[0]->image)); ?>

													<?php endif; ?>" alt="img">
										</a>
									</div>
								</div>
								<div class="col-sm-7 add-desc-box">
									<div class="add-details">
										<h5 class="add-title">
											<a href="<?php echo e(url(sprintf('product/%d/%s',$product->id,make_slug($product->name)))); ?>"> 
												<?php echo e($product->name); ?>

											</a>
										</h5>
											<span class="info-row"> 
												<span class="add-type business-ads tooltipHere" data-toggle="tooltip" data-placement="right" title="" data-original-title="Business Ads">
													B 
												</span>
												 <span class="date">
												 	<i class=" icon-clock"> </i> <?php echo e(Carbon\Carbon::parse($product->created_at)->diffForHumans()); ?> 
												 </span> - <span class="category"><?php echo e($product->category->name); ?> </span>- 
												 <span class="item-location"><i class="fa fa-map-marker"></i> <?php echo e($product->producr_location_city->name); ?> </span> 
											</span>
										</div>
									</div>

									<div class="col-sm-3 text-right  price-box">
										<h2 class="item-price"> <?php echo e(currency_code()); ?> <?php echo e($product->single_price); ?> </h2>
										<a class="btn btn-danger  btn-sm make-favorite"> 
											<i class="fa fa-certificate"></i> 
											<span>
												<?php if($product->premiun_status == 1): ?>
													<?php echo e("Urgent"); ?>

												<?php elseif($product->premiun_status == 2): ?>
													<?php echo e("Top Ads"); ?>

												<?php elseif($product->premiun_status == 3): ?>
													<?php echo e("Featured Ads"); ?>

												<?php endif; ?>
											</span> 
										</a> 
									</div>
								</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
				</div>