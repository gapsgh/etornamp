<?php $__env->startSection('content'); ?>
	<h2 class="pull-right">Create Category</h2>
	<form>
		
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>