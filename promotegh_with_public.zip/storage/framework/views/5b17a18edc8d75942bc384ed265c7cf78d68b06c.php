<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('/assets/ico/apple-touch-icon-144-precomposed.png')); ?>">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('/assets/ico/apple-touch-icon-114-precomposed.png')); ?>">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('/assets/ico/apple-touch-icon-72-precomposed.png')); ?>">
<link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
<link rel="shortcut icon" href="<?php echo e(asset('/assets/ico/favicon.png')); ?>">

<link href="<?php echo e(asset('/assets/css/materialize.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
<link href="<?php echo e(asset('/assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('/assets/css/style.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('/assets/css/owl.carousel.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/owl.theme.css')); ?>" rel="stylesheet">
<link href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet">

<link href="<?php echo e(asset('/assets/plugins/lightGallery-master/dist/css/lightgallery.css')); ?>" rel="stylesheet">

 
<link href="<?php echo e(asset('/assets/plugins/bxslider/jquery.bxslider.css')); ?>" rel="stylesheet"/>

<link href="<?php echo e(asset('/assets/css/my.css')); ?>" rel="stylesheet">