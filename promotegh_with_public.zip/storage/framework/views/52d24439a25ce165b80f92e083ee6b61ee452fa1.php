	<div class="modal fade" id="changeLocation" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span>
						</button>
						<h4 class="modal-title"><i class=" icon-location-2"></i> Select A Location </h4>
					</div>
					<div class="modal-body">


						<div class="location_container"  id="page_container">

							<div id="accordion_search_bar_container" class="form-group">
								<input class="form-control input-md" type="search" id="accordion_search_bar"  placeholder="Search Your Location"/>
							</div>

							<div class="panel-group"  id="accordion"  role="tablist" aria-multiselectable="true">

								<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $main_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


								<div class="panel panel-success" id="collapse<?php echo e($key); ?>_container">
									<div class="panel-heading" role="tab" id="heading<?php echo e($key); ?>">
										<h4 class="panel-title">
											<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($key); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($key); ?>" style="display: block;">
												<?php echo e($main_location['name']); ?>

											</a>
										</h4>
									</div>
									<div id="collapse<?php echo e($key); ?>" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading<?php echo e($key); ?>">
										<div class="panel-body">
											<?php $__currentLoopData = $main_location['sub_locations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sub_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<ul>
												<li style="padding: 6px 0px 6px 0px; border-bottom: 1px solid rgba(128, 128, 128, 0.18);">
													<span class="location_li" data-original="<?php echo e($sub_location['name']); ?>">
														<?php echo e($sub_location['name']); ?> 
													</span>
													<button onclick="$('#location_city').val('<?php echo e($sub_location['id']); ?>'); $('#company_location').val('<?php echo e($sub_location['name']); ?>')" type="button" class="btn btn-primary btn-xs pull-right" data-dismiss="modal">
														<i class=" icon-location-2"></i>select
													</button> 
												</li>
											</ul>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
								</div>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</div>
						</div>


					</div>
					<div class="modal-footer">

					</div>
				</div>
			</div>
		</div>

