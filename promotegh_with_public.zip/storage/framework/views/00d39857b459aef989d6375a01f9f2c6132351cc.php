<div class="post-promo text-center">
	<h2> Do you have Ghana Made Product for sale ? </h2>
	<h5>Sell your products here FOR FREE. It's easier than you think !</h5>
	<a href="<?php echo e(url('/products/create')); ?>" class="btn btn-lg btn-border btn-post btn-danger">
		Post a Free GM Product 
	</a>
</div>