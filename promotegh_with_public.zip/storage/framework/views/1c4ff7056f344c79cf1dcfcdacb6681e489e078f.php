<aside>

	<div class="inner-box">
		<div class="user-panel-sidebar">

			<div class="collapse-box">
				<h5 class="collapse-title no-border"> My Dashboard <a href="#MyClassified" data-toggle="collapse" class="pull-right"><i class="fa fa-angle-down"></i></a></h5>
				<div class="panel-collapse collapse in" id="MyClassified">
					<ul class="acc-list">
						<li>
							<a class="<?php echo e(Request::path() == 'account/dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('dashboard_path')); ?>">
								<i class="icon-home"></i> Personal Home 
							</a>
						</li>
					</ul>
				</div>
			</div>

			<div class="collapse-box">
				<h5 class="collapse-title"> My Ads <a href="#MyAds" data-toggle="collapse" class="pull-right"><i class="fa fa-angle-down"></i></a></h5>
				<div class="panel-collapse collapse in" id="MyAds">
					<ul class="acc-list">
						<li>
							<a class="<?php echo e(Request::path() == 'account/dashboard/my-products' ? 'active' : ''); ?>" href="<?php echo e(route('dashboard_myproducts_path')); ?>">
								<i class="icon-docs"></i>
								 All ads 
								 <span class="badge">
									<?php
									if (isset($products)) {
										echo count($products);
									}else{
										echo '0';
									}
									?>
								</span> 
							</a>
						</li>
						
						<li>
							<a class="<?php echo e(Request::path() == 'account/dashboard/pending-approval' ? 'active' : ''); ?>" href="<?php echo e(route('dashboard_unapproved_path')); ?>">
								<i class="icon-hourglass"></i>
								 Pending approval 
								 <span class="badge">
								 	<?php
									if (isset($unapproved_products)) {
										echo count($unapproved_products);
									}
									?>
								 </span>
							</a>
						</li>
						<li>
							<a class="<?php echo e(Request::path() == 'account/dashboard/approved-ads' ? 'active' : ''); ?>" 
								href="<?php echo e(route('dashboard_approved_path')); ?>">
								<i class="icon-check"></i>
								 Approved Ads 
								 <span class="badge">
								 	<?php
									if (isset($approved_products)) {
										echo count($approved_products);
									}else{
										echo "0";
									}
									?>
								 </span>
							</a>
						</li>

					</ul>
				</div>
			</div>

			

		</div>
	</div>

</aside>